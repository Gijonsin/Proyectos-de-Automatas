#ifndef DIALOG_H
#define DIALOG_H
#include "notacionpolaca.h"
#include <QDialog>
#include <QKeyEvent>
#include <QStringListModel>


QT_BEGIN_NAMESPACE
namespace Ui { class Dialog; }
QT_END_NAMESPACE

class Dialog : public QDialog
{
    Q_OBJECT

public:
    Dialog(QWidget *parent = nullptr);
    ~Dialog();

private slots:
    void on_pushBtn_Convertir_clicked();

    void on_pushBtn_Solucion_clicked();

    void on_pushBtn_LimpiarCampos_clicked();

    void keyPressEvent(QKeyEvent *evt);

private:
    Ui::Dialog *ui;
    NotacionPolaca *np;

    QStringList historial;
    QStringListModel modelo;
};
#endif // DIALOG_H
