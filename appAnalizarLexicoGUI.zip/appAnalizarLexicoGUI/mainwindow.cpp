#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTextBlock>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionSalir_triggered()
{
    QMessageBox::StandardButton respuesta = QMessageBox::question(this,"CONFIRMACIÓN","¡ESTAS SEGURO DE QUERER SALIR?",QMessageBox::Yes|QMessageBox::No);
    if(respuesta == QMessageBox::Yes)
        exit(0);
}


void MainWindow::on_actionAbrir_triggered()
{
    QString nombreArchivo = QFileDialog::getOpenFileName(this, tr("Open File"), "/home/gijonsin/","All files (*.*);;Text File (*.txt);;");
    //QMessageBox::information(this,tr("Nombre Archivo"),nombreArchivo);
    ifstream archivo(nombreArchivo.toStdString());


    string linea;
    if(!archivo.is_open())
        QMessageBox::warning(this,"EROR AL ABRIR EL ARCHIVO","NO SE PUDO LEER EL ARCHIVO");

    while(getline(archivo,linea))
    {
        ui->textEdit_Entrada->append(QString::fromStdString(linea));
    }
}


void MainWindow::on_pushBtn_Scanner_clicked()
{
    ui->textEdit_Salida->setText("");
    char cadenaC[255];
    QString textoPlano = ui->textEdit_Entrada->toPlainText();
    QTextStream texto(&textoPlano);

    while(!texto.atEnd()){
        QString linea = texto.readLine();
        strcpy(cadenaC,linea.toStdString().c_str());
        ui->textEdit_Salida->append(lexico.scanner2(cadenaC));
        ui->textEdit_Salida->append("--------------------------------");
    }
}


void MainWindow::on_actionGuardar_triggered()
{
    QString texto = ui->textEdit_Entrada->toPlainText();

    QString nombreArchivo = QFileDialog::getSaveFileName(this,tr("Save File"), "",tr("Text Files (*.txt)"));

    if(nombreArchivo.isEmpty())
        return;

    ofstream archivoSalida(nombreArchivo.toStdString());

    if(!archivoSalida)
    {
        QMessageBox::warning(this,"EROR AL ABRIR EL ARCHIVO","NO SE PUDO LEER EL ARCHIVO");
        return;
    }

    archivoSalida << texto.toStdString();

    archivoSalida.close();
}


void MainWindow::on_actionAcerca_De_triggered()
{
    QMessageBox::about(this, "Acerca de",
                       "<h2>Nombre de la Aplicación v1.0</h2>"
                       "<p>Desarrollado por: Tu Nombre</p>"
                       "<p>Esta aplicación hace XYZ.</p>"
                       "<p>Para más información, visita nuestro sitio web.</p>");
}

