#include "notacionpolaca.h"


NotacionPolaca::NotacionPolaca()
{

}

char *NotacionPolaca::convertirAPostfija(string expInfija)
{
    // EXPOSFIJA = SALIDA
    char *expPosfija = new char[expInfija.length()];

    pilaT <int> *stack = new pilaT<int>(this->numOperadores(expInfija));
    int pos = 0;
    for(int i=0; i<(int)expInfija.length(); i++)
    {
        char car = expInfija[i];
        Simbolo actual = tipoYPrecendencia(car);
        switch (actual) {
            case OPERANDO: expPosfija[pos++] = car; break;
        case SUMRES: {
            while(!stack->estaVacia() && tipoYPrecendencia(stack->Tope()) >= actual)
            {
                expPosfija[pos++] = stack->pop();
            }
            stack->push(car);
            break;
        }
        case MULTDIV:
            while(!stack->estaVacia() && tipoYPrecendencia(stack->Tope()) >= actual)
            {
                expPosfija[pos++] = stack->pop();
            }
            stack->push(car);
            break;
        case POW:
            while(!stack->estaVacia() && tipoYPrecendencia(stack->Tope()) >= actual)
            {
                expPosfija[pos++] = stack->pop();
            }
            stack->push(car);
            break;
        case PIZQ: stack->push(car); break;
        case PDER:
            char x = stack->pop();
            while(tipoYPrecendencia(x) != PIZQ)
            {
                expPosfija[pos++] = x;
                x = stack->pop();
            }

        }
    }

    while(!stack->estaVacia())
    {
        //expPosfija[pos++] = stack->pop();
        if(pos < (int)expInfija.length())
            expPosfija[pos++] = stack->pop();
        else
            break;
    }

    expPosfija[pos] = '\0'; // LAS CADENAS DE C/C++ TERMINAN EN NULO

    return expPosfija;

}

QString NotacionPolaca::convertirAPostfija(QString expInfija)
{
    //char *expPosfija = new char[expInfija.length()];
    QString expPosfija = "";
    pilaT <QChar> *stack = new pilaT<QChar>(this->numOperadores(expInfija.toStdString()));
    int pos = 0;
    for(int i=0; i<(int)expInfija.length(); i++)
    {
        QChar car = expInfija[i];
        Simbolo actual = tipoYPrecendencia(car.toLatin1());
        switch (actual) {
            case OPERANDO: expPosfija.append(car); break;
        case SUMRES: {
            while(!stack->estaVacia() && tipoYPrecendencia(stack->Tope().toLatin1()) >= actual)
            {
                expPosfija.append(stack->pop());
            }
            stack->push(car);
            break;
        }
        case MULTDIV:
            while(!stack->estaVacia() && tipoYPrecendencia(stack->Tope().toLatin1()) >= actual)
            {
                expPosfija.append(stack->pop());
            }
            stack->push(car);
            break;
        case POW:
            while(!stack->estaVacia() && tipoYPrecendencia(stack->Tope().toLatin1()) >= actual)
            {
                expPosfija.append(stack->pop());
            }
            stack->push(car);
            break;
        case PIZQ: stack->push(car); break;
        case PDER:
            QChar x = stack->pop();
            while(tipoYPrecendencia(x.toLatin1()) != PIZQ)
            {
                expPosfija.append(x);
                x = stack->pop();
            }

        }
    }

    while(!stack->estaVacia())
    {
        //expPosfija[pos++] = stack->pop();
        if(pos < (int)expInfija.length())
            expPosfija.append(stack->pop());
        else
            break;
    }

    //expPosfija[pos] = '\0'; // LAS CADENAS DE C/C++ TERMINAN EN NULO
    delete stack;
    return expPosfija;
}

string NotacionPolaca::convertirAPostfija(char* expInfija)
{
    // EXPOSFIJA = SALIDA
    int longitud = largo(expInfija);
    char *expPosfija = new char[longitud];

    pilaT <int> *stack = new pilaT<int>(this->numOperadores(expInfija));
    int pos = 0;
    for(int i=0; i<longitud; i++)
    {
        char car = expInfija[i];
        Simbolo actual = tipoYPrecendencia(car);
        switch (actual) {
            case OPERANDO: expPosfija[pos++] = car; break;
        case SUMRES: {
            while(!stack->estaVacia() && tipoYPrecendencia(stack->Tope()) >= actual)
            {
                expPosfija[pos++] = stack->pop();
            }
            stack->push(car);
            break;
        }
        case MULTDIV:
            while(!stack->estaVacia() && tipoYPrecendencia(stack->Tope()) >= actual)
            {
                expPosfija[pos++] = stack->pop();
            }
            stack->push(car);
            break;
        case POW:
            while(!stack->estaVacia() && tipoYPrecendencia(stack->Tope()) >= actual)
            {
                expPosfija[pos++] = stack->pop();
            }
            stack->push(car);
            break;
        case PIZQ: stack->push(car); break;
        case PDER:
            char x = stack->pop();
            while(tipoYPrecendencia(x) != PIZQ)
            {
                expPosfija[pos++] = x;
                x = stack->pop();
            }

        }
    }

    while(!stack->estaVacia())
    {
        //expPosfija[pos++] = stack->pop();
        if(pos < longitud)
            expPosfija[pos++] = stack->pop();
        else
            break;
    }

    expPosfija[pos] = '\0'; // LAS CADENAS DE C/C++ TERMINAN EN NULO

    return expPosfija;
}

char *NotacionPolaca::convertirAPrefija(string expInfija)
{
   /*expInfija = invertirCadena(expInfija);
   char *expPrefija = new char(expInfija.length());

   pilaT<char> *stack = new pilaT<char>(numOperadores(expInfija));

   int pos = 0;

   for(int i=0; i<expInfija.length(); i++)
   {

   }*/


}

char *NotacionPolaca::invertirCadena(string cad)
{
    char *cadAux = new char[cad.length()];
    int pos = 0;
    for(int i=cad.length()-1; i>=0; i--)
        cadAux[pos++] = cad.at(i);
    return cadAux;
}

double NotacionPolaca::convertirCaracterANum(char c)
{
    return c-42;
}

double NotacionPolaca::evaluarOperacion(double n1, double n2, char operador)
{
    double resultado = 0;
    switch(operador)
    {
        case '+': resultado = n1+n2; break;
        case '-': resultado = n1-n2; break;
        case '*': resultado = n1*n2; break;
        case '/': resultado = n1/n2; break;
        case '^': resultado = pow(n1,n2); break;

    }
    return resultado;
}

double NotacionPolaca::resolverExpPostfija(string expPostfija)
{
    pilaT<double> *stack = new pilaT<double>(expPostfija.length());
    double r = 0;
    for(int i=0; i<expPostfija.length(); i++)
    {
        char car = expPostfija.at(i);
        if(car>='0' && car<='9')
            stack->push(convertirCaracterANum(car));
        else if(car == '+' || car == '-' || car == '*' || car == '/' || car == '^')
        {
            /*if (stack->getTope() < 2)
                return 0;*/

            double n2 = stack->pop();
            double n1 = stack->pop();
            r = evaluarOperacion(n1,n2,car);
            stack->push(r);
        }
    }

    /*if (stack->getTope() != 1)
        return 0;*/

    return stack->pop();
}

double NotacionPolaca::resolverExpPostfija(QString expPostfija)
{
    double a = 0, b = 0, resultado = 0;
    int i=0;
    int longitud = expPostfija.length();
    char elemento;
    pilaT<double> *stack = new pilaT<double>(longitud);
    while(i<longitud)
    {
        elemento = expPostfija.at(i).toLatin1();
        i++;
        if(esOperando(elemento))
            stack->push(elemento - '0');
        else
        {
            b = stack->pop();
            a = stack->pop();
            resultado = evaluarOperacion(a,b,elemento);
            stack->push(resultado);
        }
    }
    return stack->pop();
}

int NotacionPolaca::largo(char *cad)
{
    int i=0;
    while(cad[i] != '\0')
        i++;
    return i;
}

Simbolo NotacionPolaca::tipoYPrecendencia(char c)
{
    Simbolo simbolo;
    switch (c) {
        case '+':
        case '-': simbolo = SUMRES; break;
        case '*':
        case '/': simbolo = MULTDIV; break;
        case '^': simbolo = POW; break;
        case '(': simbolo = PIZQ; break;
        case ')': simbolo = PDER; break;
        default: simbolo = OPERANDO; break;
    }
    return simbolo;
}
//IMPLEMENTAR UN METODO PARA DETERMINAR LA CANTIDAD DE OPERADORES EN LA EXPRESION INFIJA
int NotacionPolaca::numOperadores(string expInfija)
{
    int cont = 0;
    for(int i=0; i<(int)expInfija.length(); i++)
        if(expInfija.at(i) == '+' || expInfija.at(i) == '-' || expInfija.at(i) == '*' || expInfija.at(i) == '/' || expInfija.at(i) == '(' || expInfija.at(i) == '^' || expInfija.at(i) == ')')
            cont++;

    return cont;
}

//IMPLEMENTAR UN METODO PARA CONTAR LA CANTIDAD DE PARENTESIS
//TAMBIEN VALIDAR QUE LOS PARENTESIS ESTEN APAREADOS
//O NO ESTE EL PAR CORRESPONDIENTE

bool NotacionPolaca::validarExpresion(string expInfija)
{
    pilaT <char> *stack = new pilaT<char>(expInfija.length());
    for(int i=0; i<(int)expInfija.length(); i++)
    {
        if(expInfija.at(i) == '(')
            stack->push(expInfija.at(i));
        else if(expInfija.at(i) == ')')
        {
            if(stack->estaVacia())
                return false;
            stack->pop();
        }



    }

    for(int i = 0; i < (int)expInfija.length(); i++) {
                char caracter = expInfija.at(i);
                if (!((caracter >= 'A' && caracter <= 'Z') || (caracter >= 'a' && caracter <= 'z') ||
                      caracter == '(' || caracter == ')' || caracter == '+' || caracter == '-' || caracter == '*'
                      || caracter == '/' || caracter == '^' || (caracter >= '0' && caracter <= '9'))) {
                    return false;
                }
            }
    return stack->estaVacia();
}

bool NotacionPolaca::validarExpresionParaResolver(QString expInfija)
{
    pilaT <QChar> *stack = new pilaT<QChar>(expInfija.length());
    for(int i=0; i<(int)expInfija.length(); i++)
    {
        if(expInfija.at(i) == '(')
            stack->push(expInfija.at(i));
        else if(expInfija.at(i) == ')')
        {
            if(stack->estaVacia())
                return false;
            stack->pop();
        }

    }

    for(int i = 0; i < (int)expInfija.length(); i++)
    {
        QChar caracter = expInfija.at(i);
        if (!(caracter == '(' || caracter == ')' || caracter == '+' || caracter == '-' || caracter == '*'|| caracter == '/' || caracter == '^' || (caracter >= '0' && caracter <= '9')))
        {
            return false;
        }
    }

    return stack->estaVacia();
}

bool NotacionPolaca::esOperando(char c)
{
    if(c>='0' && c<='9')
        return true;
    else
        return false;

}

bool NotacionPolaca::esOperador(char c)
{
    if(c == '+' || c == '-' || c == '*' || c == '/' || c == '^')
        return true;
    else
        return false;
}


