#include "analizadorlexico.h"

AnalizadorLexico::AnalizadorLexico()
{

}

void AnalizadorLexico::scanner(char cadena[255])
{
    char caracter;
    inicializaEstados();
    i = inicioToken = 0;
    while(i < strlen(cadena) || estadoDeAceptacion())
    {
        switch (estadoActual) {
        case 0:
            caracter = leerCar(i);
            if(esDelimitador(caracter))
                estadoActual = 1;
            else
                cambiarEstado(); //CAMBIO DE ESTADO
            break;
        case 1:
            caracter = leerCar(i);
            if(esDelimitador(caracter))
                estadoActual = 1;
            else
                estadoActual = 2;
            break;
        case 2:
            retrocedeCar; //SERIA EL * DEL DIAGRAMA DE TRANSICIONES
            cout<<"\n DELIMITADOR";
            inicializaEstados();
            inicioToken = i;
            break;
        case 3:
            caracter = leerCar(i);
            if(esLetra(caracter) || caracter == '_')
                estadoActual = 4;
            else
                cambiarEstado();
            break;
        case 4:
            caracter = leerCar(i);
            if(esLetra(caracter) || esDigito(caracter) || caracter == '_')
                estadoActual = 4;
            else
                estadoActual = 5;
            break;

        case 5:
            retrocedeCar;
            cout<<"\n IDENTIFICADOR";
            inicializaEstados();
            inicioToken = i;
            break;

        case 6:
            caracter = leerCar(i);
            if(esDigito(caracter))
                estadoActual = 7;
            else
                cambiarEstado();
            break;

        case 7:
            caracter = leerCar(i);
            if(esDigito(caracter))
                estadoActual = 7;
            else if(caracter == '.')
                estadoActual = 9;
            else
                estadoActual = 8;
            break;

        case 8:
            retrocedeCar;
            cout<<"\nNUMERO ENTERO";
            inicializaEstados();
            inicioToken = i;
            break;

        case 9:
            caracter = leerCar(i);
            if(esDigito(caracter))
                estadoActual = 9;
            else
                estadoActual = 10;
            break;

        case 10:
            retrocedeCar;
            cout<<"\nNUMERO REAL";
            inicializaEstados();
            inicioToken = i;
            break;

            //CONTINUAR CON LOS OPERADORES LOGICOS, RELACIONALES Y ARITMETICOS
        case 11:
            caracter = leerCar(i);
            if(caracter == '=')
                estadoActual = 12;
            else
                cambiarEstado();
            break;

        case 12:
            caracter = leerCar(i);
            if(caracter == '=')
                estadoActual = 14;
            else
                estadoActual = 13;
            break;

        case 13:
            retrocedeCar;
            cout<<"\n OPERADOR DE ASIGNACION";
            inicializaEstados();
            inicioToken = i;
            break;

        case 14:
            /*caracter = leerCar(i);
            estadoActual = 15;
            break;*/

            cout<<"\n OPERADOR RELACIONAL";
            inicializaEstados();
            inicioToken = i;
            break;

        case 15:
            /*retrocedeCar;
            cout<<"\n OPERADOR RELACIONAL";
            inicializaEstados();
            inicioToken = i;
            break;*/

            caracter = leerCar(i);
            if(caracter == '!')
                estadoActual = 16;
            else
                cambiarEstado();
            break;

        case 16:
            /*caracter = leerCar(i);
            if(caracter == '!')
                estadoActual = 17;
            else
                fallo();
            break;*/

            caracter = leerCar(i);
            if(caracter == '=')
                estadoActual = 17;
            else
                estadoActual = 18;
            break;

        case 17:
            /*caracter = leerCar(i);
            if(caracter == '=')
                estadoActual = 19;
            else
                estadoActual = 18;
            break;*/

            cout<<"\n OPERADOR RELACIONAL";
            inicializaEstados();
            inicioToken = i;
            break;

        case 18:
            retrocedeCar;
            cout<<"\n OPERADOR LOGICO";
            inicializaEstados();
            inicioToken = i;
            break;
    //  OPERADORES >, >=
        case 19:
            /*caracter = leerCar(i);
            estadoActual = 20;
            break;*/
            caracter = leerCar(i);
            if(caracter == '>')
                estadoActual = 20;
            else
                cambiarEstado();
            break;

        case 20:
            /*retrocedeCar;
            cout<<"\n OPERADOR RELACIONAL";
            inicializaEstados();
            inicioToken = i;
            break;*/

            caracter = leerCar(i);
            if(caracter == '=')
                estadoActual = 22;
            else
                estadoActual = 21;
            break;

        case 21:
            /*caracter = leerCar(i);
            if(caracter == '>')
                estadoActual = 22;
            else
                fallo();
            break;*/
            retrocedeCar;
            cout<<"\n OPERADOR RELACIONAL";
            inicializaEstados();
            inicioToken = i;
            break;

        case 22:
            /*caracter = leerCar(i);
            if(caracter == '=')
                estadoActual = 24;
            else
                estadoActual = 23;
            break;*/
            //retrocedeCar;
            cout<<"\n OPERADOR RELACIONAL";
            inicializaEstados();
            inicioToken;
            break;
    //<, <=
        case 23:
            caracter = leerCar(i);
            if(caracter == '<')
                estadoActual = 24;
            else
                cambiarEstado();
            break;

        case 24:
            caracter = leerCar(i);
            if(caracter == '=')
                estadoActual = 26;
            else
                estadoActual = 25;
            break;

        case 25:
            retrocedeCar;
            cout<<"\n OPERADOR RELACIONAL";
            inicializaEstados();
            inicioToken;
            break;

        case 26:
            cout<<"\n OPERADOR RELACIONAL";
            inicializaEstados();
            inicioToken = i;
            break;

        case 27:
            caracter = leerCar(i);
            if(caracter == '+')
                estadoActual = 28;
            else
                cambiarEstado();
            break;

        case 28:
            cout<<"\n OPERADOR ARITMETICO MAS";
            inicializaEstados();
            inicioToken = i;
            break;

        case 29:
            caracter = leerCar(i);
            if(caracter == '-')
                estadoActual = 30;
            else
                cambiarEstado();
            break;

        case 30:
            cout<<"\n OPERADOR ARITMETICO MENOS";
            inicializaEstados();
            inicioToken = i;
            break;

        case 31:
            caracter = leerCar(i);
            if(caracter == '*')
                estadoActual = 32;
            else
                cambiarEstado();
            break;

        case 32:
            cout<<"\n OPERADOR ARITMETICO MULTIPLICACION";
            inicializaEstados();
            inicioToken = i;
            break;

        case 33:
            caracter = leerCar(i);
            if(caracter == '/')
                estadoActual = 34;
            else
                cambiarEstado();
            break;

        case 34:
            cout<<"\n OPERADOR ARITMETICO DIVISION";
            inicializaEstados();
            inicioToken = i;
            break;

        case 35:
            caracter = leerCar(i);
            if(caracter == '%')
                estadoActual = 36;
            else
                cambiarEstado();
            break;

        case 36:
            cout<<"\n OPERADOR DE MODULO";
            inicializaEstados();
            inicioToken = i;
            break;

        }
    }
}

QString AnalizadorLexico::scanner2(char cadena[255])
{
    QString salida = "";
    char caracter;
    inicializaEstados();
    i = inicioToken = 0;
    while(i < strlen(cadena) || estadoDeAceptacion())
    {
        switch (estadoActual) {
        case 0:
            caracter = leerCar(i);
            if(esDelimitador(caracter))
                estadoActual = 1;
            else
                cambiarEstado(); //CAMBIO DE ESTADO
            break;
        case 1:
            caracter = leerCar(i);
            if(esDelimitador(caracter))
                estadoActual = 1;
            else
                estadoActual = 2;
            break;
        case 2:
            retrocedeCar; //SERIA EL * DEL DIAGRAMA DE TRANSICIONES
            //cout<<"\n DELIMITADOR";
            salida += "DELIMITADOR\n";
            inicializaEstados();
            inicioToken = i;
            break;
        case 3:
            caracter = leerCar(i);
            if(esLetra(caracter) || caracter == '_')
                estadoActual = 4;
            else
                cambiarEstado();
            break;
        case 4:
            caracter = leerCar(i);
            if(esLetra(caracter) || esDigito(caracter) || caracter == '_')
                estadoActual = 4;
            else
                estadoActual = 5;
            break;

        case 5:
            retrocedeCar;
            //cout<<"\n IDENTIFICADOR";
            salida += "IDENTIFICADOR\n";
            inicializaEstados();
            inicioToken = i;
            break;

        case 6:
            caracter = leerCar(i);
            if(esDigito(caracter))
                estadoActual = 7;
            else
                cambiarEstado();
            break;

        case 7:
            caracter = leerCar(i);
            if(esDigito(caracter))
                estadoActual = 7;
            else if(caracter == '.')
                estadoActual = 9;
            else
                estadoActual = 8;
            break;

        case 8:
            retrocedeCar;
            //cout<<"\nNUMERO ENTERO";
            salida += "NUMERO ENTERO\n";
            inicializaEstados();
            inicioToken = i;
            break;

        case 9:
            caracter = leerCar(i);
            if(esDigito(caracter))
                estadoActual = 9;
            else
                estadoActual = 10;
            break;

        case 10:
            retrocedeCar;
            //cout<<"\nNUMERO REAL";
            salida += "NUMERO REAL\n";
            inicializaEstados();
            inicioToken = i;
            break;

            //CONTINUAR CON LOS OPERADORES LOGICOS, RELACIONALES Y ARITMETICOS
        case 11:
            caracter = leerCar(i);
            if(caracter == '=')
                estadoActual = 12;
            else
                cambiarEstado();
            break;

        case 12:
            caracter = leerCar(i);
            if(caracter == '=')
                estadoActual = 14;
            else
                estadoActual = 13;
            break;

        case 13:
            retrocedeCar;
            //cout<<"\n OPERADOR DE ASIGNACION";
            salida += "OPERADOR DE ASIGNACION\n";
            inicializaEstados();
            inicioToken = i;
            break;

        case 14:
            /*caracter = leerCar(i);
            estadoActual = 15;
            break;*/

            //cout<<"\n OPERADOR RELACIONAL";
            salida += "OPERADOR RELACIONAL\n";
            inicializaEstados();
            inicioToken = i;
            break;

        case 15:
            /*retrocedeCar;
            cout<<"\n OPERADOR RELACIONAL";
            inicializaEstados();
            inicioToken = i;
            break;*/

            caracter = leerCar(i);
            if(caracter == '!')
                estadoActual = 16;
            else
                cambiarEstado();
            break;

        case 16:
            /*caracter = leerCar(i);
            if(caracter == '!')
                estadoActual = 17;
            else
                fallo();
            break;*/

            caracter = leerCar(i);
            if(caracter == '=')
                estadoActual = 17;
            else
                estadoActual = 18;
            break;

        case 17:
            /*caracter = leerCar(i);
            if(caracter == '=')
                estadoActual = 19;
            else
                estadoActual = 18;
            break;*/

            //cout<<"\n OPERADOR RELACIONAL";
            salida += "OPERDARO RELACIONAL\n";
            inicializaEstados();
            inicioToken = i;
            break;

        case 18:
            retrocedeCar;
            //cout<<"\n OPERADOR LOGICO";
            salida += "OPERADOR LOGICO\n";
            inicializaEstados();
            inicioToken = i;
            break;
    //  OPERADORES >, >=
        case 19:
            /*caracter = leerCar(i);
            estadoActual = 20;
            break;*/
            caracter = leerCar(i);
            if(caracter == '>')
                estadoActual = 20;
            else
                cambiarEstado();
            break;

        case 20:
            /*retrocedeCar;
            cout<<"\n OPERADOR RELACIONAL";
            inicializaEstados();
            inicioToken = i;
            break;*/

            caracter = leerCar(i);
            if(caracter == '=')
                estadoActual = 22;
            else
                estadoActual = 21;
            break;

        case 21:
            /*caracter = leerCar(i);
            if(caracter == '>')
                estadoActual = 22;
            else
                fallo();
            break;*/
            retrocedeCar;
            //cout<<"\n OPERADOR RELACIONAL";
            salida += "OPERADOR RELACIONAL\n";
            inicializaEstados();
            inicioToken = i;
            break;

        case 22:
            /*caracter = leerCar(i);
            if(caracter == '=')
                estadoActual = 24;
            else
                estadoActual = 23;
            break;*/
            //retrocedeCar;
            //cout<<"\n OPERADOR RELACIONAL";
            salida += "OPERADOR RELACIONAL\n";
            inicializaEstados();
            inicioToken;
            break;
    //<, <=
        case 23:
            caracter = leerCar(i);
            if(caracter == '<')
                estadoActual = 24;
            else
                cambiarEstado();
            break;

        case 24:
            caracter = leerCar(i);
            if(caracter == '=')
                estadoActual = 26;
            else
                estadoActual = 25;
            break;

        case 25:
            retrocedeCar;
            //cout<<"\n OPERADOR RELACIONAL";
            salida += "OPERADOR RELACIONAL\n";
            inicializaEstados();
            inicioToken;
            break;

        case 26:
            //cout<<"\n OPERADOR RELACIONAL";
            salida += "OPERADOR RELACIONAL\n";
            inicializaEstados();
            inicioToken = i;
            break;

        case 27:
            caracter = leerCar(i);
            if(caracter == '+')
                estadoActual = 28;
            else
                cambiarEstado();
            break;

        case 28:
            //cout<<"\n OPERADOR ARITMETICO MAS";
            salida += "OPERADOR ARITMETICO MAS\n";
            inicializaEstados();
            inicioToken = i;
            break;

        case 29:
            caracter = leerCar(i);
            if(caracter == '-')
                estadoActual = 30;
            else
                cambiarEstado();
            break;

        case 30:
            //cout<<"\n OPERADOR ARITMETICO MENOS";
            salida += "OPERADOR ARITMETICO MENOS\n";
            inicializaEstados();
            inicioToken = i;
            break;

        case 31:
            caracter = leerCar(i);
            if(caracter == '*')
                estadoActual = 32;
            else
                cambiarEstado();
            break;

        case 32:
            //cout<<"\n OPERADOR ARITMETICO MULTIPLICACION";
            salida += "OPERADOR ARITMETICO MULTIPLICACION\n";
            inicializaEstados();
            inicioToken = i;
            break;

        case 33:
            caracter = leerCar(i);
            if(caracter == '/')
                estadoActual = 34;
            else
                cambiarEstado();
            break;

        case 34:
            //cout<<"\n OPERADOR ARITMETICO DIVISION";
            salida += "OPERADOR ARITMETICO DIVISION\n";
            inicializaEstados();
            inicioToken = i;
            break;

        case 35:
            caracter = leerCar(i);
            if(caracter == '%')
                estadoActual = 36;
            else
                cambiarEstado();
            break;

        case 36:
            //cout<<"\n OPERADOR DE MODULO";
            salida += "OPERADOR DE MODULO\n";
            inicializaEstados();
            inicioToken = i;
            break;

        }
    }

    return salida;
}

void AnalizadorLexico::inicializaEstados()
{
    estadoInicial = estadoActual = 0;
}

void AnalizadorLexico::cambiarEstado()
{
    switch(estadoInicial)
    {
        case 0:
            estadoInicial = 3;
            i = inicioToken;
        break;

        case 3:
            estadoInicial = 6;
            i = inicioToken;
        break;

        case 6:
            estadoInicial = 11;
            i = inicioToken;
        break;

        case 11:
            /*estadoInicial = 16;*/
            estadoInicial = 15;
            i = inicioToken;
        break;

    case 15:
        estadoInicial = 19;
        i = inicioToken;
        break;


    /*case 16:
        estadoInicial = 21;
        i = inicioToken;
        break;*/

    case 19:
        estadoInicial = 23;
        i = inicioToken;
        break;

    case 23:
        estadoInicial = 27;
        i = inicioToken;
        break;

    case 27:
        estadoInicial = 29;
        i = inicioToken;
        break;

    case 29:
        estadoInicial = 31;
        i = inicioToken;
        break;

    case 31:
        estadoInicial = 33;
        i = inicioToken;
        break;

    case 33:
        estadoInicial = 35;
        i = inicioToken;
        break;

    /*case 21:
        estadoInicial = 26;
        i = inicioToken;
        break;

    case 26:
        estadoInicial = 31;
        i = inicioToken;
        break;

    case 31:
        estadoInicial = 34;
        i = inicioToken;
        break;

    case 34:
        estadoInicial = 37;
        i = inicioToken;
        break;

    case 37:
        estadoInicial = 40;
        i = inicioToken;
        break;*/



    }
    estadoActual = estadoInicial;
}

bool AnalizadorLexico::estadoDeAceptacion()
{
    switch(estadoActual)
    {
        case 2:
        case 5:
        case 8:
        case 10:
        case 13:
    case 14:
        /*case 15:*/
    case 17:
        case 18:
    case 21:
    case 22:
    case 25:
    case 26:
    case 28:
    case 30:
    case 32:
    case 34:
    case 36:
        /*case 20:
        case 23:
        case 25:
        case 28:
        case 30:
        case 33:
        case 36:
        case 39:
        case 42:*/
            return true;
        default:
            return false;

    }
}

bool AnalizadorLexico::esDelimitador(char c)
{
    if(c == ' ' || c == '\n' || c == '\t')
        return true;

    return false;
}

bool AnalizadorLexico::esLetra(char c)
{
    if((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
        return true;

    return false;
}

bool AnalizadorLexico::esDigito(char c)
{
    if(c >= '0' && c<= '9')
        return true;

    return false;
}
