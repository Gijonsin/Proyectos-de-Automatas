#ifndef NOTACIONPOLACA_H
#define NOTACIONPOLACA_H
#include "pilat.h"
#include "pilat.cpp"//ES IMPORTANTE INCLUIR EL CPP SI SE ESTA UTILIZANDO TEMPLATES <T> = PLANTILLAS
#include <string>
#include <QString>
#include <cmath>
using namespace std;

enum Simbolo{OPERANDO=0,PIZQ,PDER,SUMRES,MULTDIV,POW};

class NotacionPolaca
{
public:
    NotacionPolaca();
    char *convertirAPostfija(string expInfija);
    QString convertirAPostfija(QString expInfija);
    string convertirAPostfija(char* expInfija);
    char *convertirAPrefija(string expInfija);
    char *invertirCadena(string cad);
    double convertirCaracterANum(char c);
    double evaluarOperacion(double n1, double n2, char operador);
    double resolverExpPostfija(string expPostfija);
    double resolverExpPostfija(QString expPostfija);
    int largo(char* cad);
    //string convertirAPostfija(string expInfija);
    //agregar el usp de QString

    Simbolo tipoYPrecendencia(char c);
    //(1 + 2) * 3 -----> 12+3*
    //EN LA SOLUCION SE DEBE EXTRAER EL VALOR NUMERICO DEL DIGITO
    // '1' = 1 , 49 - 48   '1' - '0' = 1

    int numOperadores(string expInfija);
    bool parentesis(string expInfija);
    bool validarExpresion(string expInfija);
    bool validarExpresionParaResolver(QString expInfija);
    bool esOperando(char c);
    bool esOperador(char c);
};

#endif // NOTACIONPOLACA_H
