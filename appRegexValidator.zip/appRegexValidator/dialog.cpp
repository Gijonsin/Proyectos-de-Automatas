#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

Dialog::~Dialog()
{
    delete ui;
}


void Dialog::on_lineEdit_Texto_textChanged(const QString &arg1)
{
    if(ui->comboBox_Regex->currentText() == "Validar Correo Electronico")
    {
        QRegularExpression regex("^[\\w-]+(\\.[\\w-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        QRegularExpressionMatch match = regex.match(arg1);
        if(match.hasMatch())
        {
            ui->label_Display->setStyleSheet("background-color: green;");
            ui->label_Display->setText("CORREO VALIDO");
        }
        else
        {
            ui->label_Display->setStyleSheet("background-color: red;");
            ui->label_Display->setText("CORREO NO VALIDO");
        }

    }
    else if(ui->comboBox_Regex->currentText() == "Validar Correo Personal")
    {
        QRegularExpression regex("^[a-z0-9_#!$%&*+/=?]{1,10}+@gijon\\.com$");
        QRegularExpressionMatch match = regex.match(arg1);
        if(match.hasMatch())
        {
            ui->label_Display->setStyleSheet("background-color: green;");
            ui->label_Display->setText("CORREO VALIDO");
        }
        else
        {
            ui->label_Display->setStyleSheet("background-color: red;");
            ui->label_Display->setText("CORREO NO VALIDO");
        }
    }
    else if(ui->comboBox_Regex->currentText() == "Validar Numero de Telefono")
    {
        QRegularExpression regex("^\\d{3}-\\d{3}-\\d{4}$");
        QRegularExpressionMatch match = regex.match(arg1);
        if(match.hasMatch())
        {
            ui->label_Display->setStyleSheet("background-color: green;");
            ui->label_Display->setText("NUMERO DE TELEFONO VALIDO");
        }
        else
        {
            ui->label_Display->setStyleSheet("background-color: red;");
            ui->label_Display->setText("NUMERO DE TELEFONO NO VALIDO");
        }
    }
    else if(ui->comboBox_Regex->currentText() == "Validar Codigo Postal")
    {
        QRegularExpression regex("^\\d{5}$");
        QRegularExpressionMatch match = regex.match(arg1);
        if(match.hasMatch())
        {
            ui->label_Display->setStyleSheet("background-color: green;");
            ui->label_Display->setText("CODIGO POSTAL VALIDO");
        }
        else
        {
            ui->label_Display->setStyleSheet("background-color: red;");
            ui->label_Display->setText("CODIGO POSTAL NO VALIDO");
        }
    }
    else if(ui->comboBox_Regex->currentText() == "Validar Numero Hexadecimal")
    {
        QRegularExpression regex("^[0-9A-Fa-f]+$");
        QRegularExpressionMatch match = regex.match(arg1);
        if(match.hasMatch())
        {
            ui->label_Display->setStyleSheet("background-color: green;");
            ui->label_Display->setText("NUMERO HEXADECIMAL VALIDO");
        }
        else
        {
            ui->label_Display->setStyleSheet("background-color: red;");
            ui->label_Display->setText("NUMERO HEXADECIMAL NO VALIDO");
        }
    }
    else
    {
        QRegularExpression regex(ui->comboBox_Regex->currentText());
        QRegularExpressionMatch match = regex.match(arg1);
        if(match.hasMatch())
        {
            ui->label_Display->setStyleSheet("background-color: green;");
            ui->label_Display->setText("COINCIDE");
        }
        else
        {
            ui->label_Display->setStyleSheet("background-color: red;");
            ui->label_Display->setText("NO COINCIDE");
        }
    }
}

