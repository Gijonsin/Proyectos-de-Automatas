#include <iostream>
#include <string>
#include <string.h>
#include <QString>

using namespace std;

const char Par[6] = "02468";
const char Non[6] = "13579";

bool analizarElNum(QString cadena)
{
    char carEntrada;
    int edoActual = 0;
    int i = 0;
    bool band = false;

    while(i<cadena.length() && !band)
    {
        switch (edoActual) {
        case 0:{
            carEntrada = cadena[i++].toLatin1();
            if(strchr(Par,carEntrada))
                edoActual = 1;
            else if(strchr(Non,carEntrada))
                edoActual = 2;

        }
           break;
        case 1:{
            carEntrada = cadena[i++].toLatin1();
            if(strchr(Par,carEntrada))
                edoActual = 1;
            else if(strchr(Non,carEntrada))
                edoActual = 2;
            else{
                edoActual = 3;
                i--;//representa el asterisco o retroceso
            }

        }
            break;
        case 2:{
            carEntrada = cadena[i++].toLatin1();
            if(strchr(Par,carEntrada))
                edoActual = 1;
            else if(strchr(Non,carEntrada))
                edoActual = 2;

        }
            break;
        case 3:{//fin de la expresion o cadena
            cout<<"NUMERO PAR"<<endl;
            band = true;
        }
            break;
        }//fin del switch
    }//fin del while

    return band;
}


bool analizarElNum(string cadena)
{
    char carEntrada;
    int edoActual = 0;
    int i = 0;
    bool band = false;

    while(i<cadena.length() && !band)
    {
        switch (edoActual) {
        case 0:{
            carEntrada = cadena[i++];
            if(strchr(Par,carEntrada))
                edoActual = 1;
            else if(strchr(Non,carEntrada))
                edoActual = 2;

        }
           break;
        case 1:{
            carEntrada = cadena[i++];
            if(strchr(Par,carEntrada))
                edoActual = 1;
            else if(strchr(Non,carEntrada))
                edoActual = 2;
            else{
                edoActual = 3;
                i--;//representa el asterisco o retroceso
            }

        }
            break;
        case 2:{
            carEntrada = cadena[i++];
            if(strchr(Par,carEntrada))
                edoActual = 1;
            else if(strchr(Non,carEntrada))
                edoActual = 2;

        }
            break;
        case 3:{//fin de la expresion o cadena
            cout<<"NUMERO PAR"<<endl;
            band = true;
        }
            break;
        }//fin del switch
    }//fin del while

    return band;
}


bool analizarElNum(char *cadena)
{
    char carEntrada;
    int edoActual = 0;
    int i = 0;
    bool band = false;

    while(i<strlen(cadena) && !band)
    {
        switch (edoActual) {
        case 0:{
            carEntrada = cadena[i++];
            if(strchr(Par,carEntrada))
                edoActual = 1;
            else if(strchr(Non,carEntrada))
                edoActual = 2;

        }
           break;
        case 1:{
            carEntrada = cadena[i++];
            if(strchr(Par,carEntrada))
                edoActual = 1;
            else if(strchr(Non,carEntrada))
                edoActual = 2;
            else{
                edoActual = 3;
                i--;//representa el asterisco o retroceso
            }

        }
            break;
        case 2:{
            carEntrada = cadena[i++];
            if(strchr(Par,carEntrada))
                edoActual = 1;
            else if(strchr(Non,carEntrada))
                edoActual = 2;

        }
            break;
        case 3:{//fin de la expresion o cadena
            cout<<"NUMERO PAR"<<endl;
            band = true;
        }
            break;
        }//fin del switch
    }//fin del while

    return band;
}

int main()
{
    char opcion;
    do{
        //AFD PARA DETERMINAR SI UNA CADENA ES UN NUMERO PAR O IMPAR
        cout << "INGRESE UNA CADENA PARA ANALIZAR: " << endl;
        string cadena;
        getline(cin,cadena,'\n');
        cadena += ";";
        //cin>>cadena;

        QString cadena1 = QString::fromStdString(cadena);

        //char *cadAux = new char(cadena.length());
        //strcpy(cadAux,cadena.c_str());

        /*if(analizarElNum(cadAux))
            cout<<"EL NUMERO ES PAR"<<endl;
        else
            cout<<"EL NUMERO ES IMPAR"<<endl;*/

        if(!analizarElNum(cadena1))
            cout<<"EL NUMERO ES IMPAR"<<endl;


        cout<<"SALIR? (s = SI ------ n = NO)"<<endl;
        cin>>opcion;
        cin.get(); //PARA ELIMINAR EL ENTER DEL BUFFER

    }while(strchr("Nn",opcion));
    return 0;
}


