#ifndef ANALIZADORLEXICO_H
#define ANALIZADORLEXICO_H

#include <iostream>
#include <string>
#include <string.h>
#include <fstream>
#include <stdlib.h>
#include <QString>

using namespace std;

class AnalizadorLexico
{
#define leerCar(i) cadena[i++]
#define retrocedeCar i--

private:
    int i, inicioToken, estadoInicial, estadoActual;

public:
    AnalizadorLexico();
    void scanner(char cadena[255]);
    QString scanner2(char cadena[255]);
    void inicializaEstados();
    void cambiarEstado();
    bool estadoDeAceptacion();
    bool esDelimitador(char c);
    bool esLetra(char c);
    bool esDigito(char c);


};

#endif // ANALIZADORLEXICO_H
