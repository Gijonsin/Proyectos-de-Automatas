#include "dialog.h"
#include "ui_dialog.h"
#include <QMessageBox>

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);
    np = new NotacionPolaca();
    setFocus();
    ui->listView_Historial->setModel(&modelo);
}

Dialog::~Dialog()
{
    delete ui;
}


void Dialog::on_pushBtn_Convertir_clicked()
{
    QString expInfija = ui->comboBox_Expresiones->currentText();
    std::string expInfAStd = expInfija.toStdString();
    if(np->validarExpresion(expInfAStd) && expInfija != "")
    {
        ui->label_notacionPostfija->setText(np->convertirAPostfija(expInfAStd));
        QString cad = ui->label_notacionPostfija->text();
        historial.prepend("Conversion: "+expInfija+" ---> "+cad);
        modelo.setStringList(historial);
    }
    else
    {
        QMessageBox::warning(this,"ADVERTENCIA","EXPRESION INVALIDA: ASEGURESE DE ESCRIBIR LA EXPRESION CORRECTAMENTE!");
        ui->comboBox_Expresiones->clear();
    }
}


void Dialog::on_pushBtn_Solucion_clicked()
{
    QString expresion = ui->comboBox_Expresiones->currentText();
    if(np->validarExpresionParaResolver(expresion) && expresion != "")
    {
        ui->label_notacionPostfija->setText(np->convertirAPostfija(expresion));
        QString resultado = "Solucion: "+np->convertirAPostfija(expresion);
        resultado.append(" = ");
        QString expresionPostfija = np->convertirAPostfija(expresion);
        resultado.append(QString::number(np->resolverExpPostfija(expresionPostfija)));
        ui->label_Resultado->setText(resultado);

        QString cad = ui->label_notacionPostfija->text();
        historial.prepend("Solucion: "+cad+" = "+QString::number(np->resolverExpPostfija(expresionPostfija)));
        modelo.setStringList(historial);
    }
    else
    {
        QMessageBox::warning(this,"ADVERTENCIA","EXPRESION INVALIDA: ASEGURESE DE ESCRIBIR LA EXPRESION CORRECTAMENTE!");
        ui->comboBox_Expresiones->clear();
    }
}


void Dialog::on_pushBtn_LimpiarCampos_clicked()
{
    ui->label_Resultado->clear();
    ui->label_notacionPostfija->clear();
    ui->comboBox_Expresiones->setCurrentIndex(0);
    historial.clear();
    modelo.setStringList(historial);
}

void Dialog::keyPressEvent(QKeyEvent *evt)
{
    if(evt->key() == Qt::Key_Escape)
    {
        QMessageBox::StandardButton pregunta;
        pregunta = QMessageBox::question(nullptr,"¿Salir?","¿Éstas seguro de que desea salir de la aplicacion?",QMessageBox::Yes|QMessageBox::No);
        if(pregunta == QMessageBox::Yes)
            exit(0);
    }

    if(evt->key() == Qt::Key_1)
        this->on_pushBtn_Convertir_clicked();

    if(evt->key() == Qt::Key_2)
        this->on_pushBtn_Solucion_clicked();

    if(evt->key() == Qt::Key_L)
        this->on_pushBtn_LimpiarCampos_clicked();

}

